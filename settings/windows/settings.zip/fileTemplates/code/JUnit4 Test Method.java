@org.junit.Test
public void test${NAME}() throws Exception {
  ${BODY}
}